CREATE DATABASE HOSPITAL;
USE HOSPITAL;
create table DOCTOR(
    DID int primary key,
    Dname varchar(20),
    Specialization varchar(20) 
)

insert into DOCTOR values
(1,'Dr. Smith','Cardiology'),
(2,'Dr. Johnson','Neurology'),
(3,'Dr. Williams','Pediatrics');

select * from DOCTOR;